---
title: "Topic 4"
description: Information on setting up pages
date: 2019-04-20T16:18:12+01:00
publishDate: 2019-04-20T19:12:12+01:00
---

### Technological and Methodological Advances in Geospatial Analysis

<!--more-->

## Research Question: 
This research delves into how cutting-edge geospatial analysis technologies and methodologies can be applied to better understand urban and regional environments. It seeks to answer: "How can advanced spatial analysis tools and methods enhance our understanding and management of complex spatial phenomena, particularly in urban settings and during critical events such as pandemics?"

## My Work:
My work in this area focuses on developing and applying novel geospatial analysis techniques to address challenges related to urban planning, emergency response, and sustainable development. By integrating advanced clustering algorithms, quasi-experimental designs, and big data analytics, I aim to provide deeper insights into how spatial data can be effectively utilized to inform policy and planning decisions. This includes exploring the dynamics of urban mobility, the robust clustering of spatial data, and the delineation of urban boundaries through data-driven approaches.

## Research Methods:

1. **Quasi-Experimental Design:** Employing quasi-experimental designs to analyze the impact of COVID-19 on travel behaviors among older adults in Shenzhen, utilizing big data from mobile phones to assess changes over time and across different urban densities and land uses.

2. **Advanced Clustering Techniques:** Utilizing innovative clustering algorithms like the Hierarchy Direction Centrality Based Clustering (HDCBC) to overcome challenges in spatial data characterized by noise, heterogeneous densities, and weak connectivity. This method enhances the robustness of spatial analyses, focusing on core points to minimize the effects of peripheral and noisy data.

3. **Data-Driven Urban Delineation:** Applying a combination of feature engineering and density-based clustering (DBSCAN) on Open Street Map data to define urban areas dynamically in Bavaria, Germany. This approach bypasses traditional limitations by adapting clustering parameters to reflect the actual morphological changes in urban environments.

## Several selected studies include:

1. Zhang, W., Xie, S., Zhao, P., Zhao, Y., Yin, J. (2022). Spatial Analysis Methodology and Application Research of Village and Town Settlements. Beijing: Science Press. (Book) (Principal author of Chapter 9)

2. Zhang, W., Li, Y., **Zhou, L.***, Fang, C. Quasi-experimental analysis of COVID-19 impacts on older adults’ travel behavior: Implications for age-friendly neighborhood planning. (the 2nd round revision to **Journal of Planning Education and Research**).

3. Fang, C., Liu, S., **Zhou, L.***, Chen, R., Werner, M. HDCBC: A Robust Clustering Algorithm for Data with Noise, Heterogeneous Densities, and Weak Connectivity. (Under review in **International Journal of Geographical Information Science**).

4. Fang, C., **Zhou, L.***, Werner, M. Data-Driven Cities – A Combination of Clustering and Feature-Engineering on Top of Open Street Map point data. (draft completed)

![topic4](/topic4/topic4.png)